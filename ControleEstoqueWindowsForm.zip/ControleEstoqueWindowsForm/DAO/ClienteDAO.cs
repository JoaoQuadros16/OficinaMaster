﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ControleEstoqueWindowsForm.DAO;
using ControleEstoqueWindowsForm.Models;
using System.Security.Cryptography;

namespace ControleEstoqueWindowsForm.DAO
{
    public class ClienteDAO
    {
        private Conexao conexao = new Conexao();

        public void CadastrarCliente(Cliente cliente)
        {
            using (MySqlConnection conn = conexao.ObterConexao())
            {
                conn.Open();
                string sql = @"INSERT INTO clientes
                           (nome, cpf, telefone, email,veiculo,placa)
                           VALUES
                           (@nome, @cpf, @telefone, @email,@veiculo,@placa);";
                MySqlCommand cmd = new MySqlCommand(sql, conn);


                cmd.Parameters.AddWithValue("@nome", cliente.Nome);
                cmd.Parameters.AddWithValue("@cpf", cliente.Cpf);
                cmd.Parameters.AddWithValue("@telefone", cliente.Telefone);
                cmd.Parameters.AddWithValue("@email", cliente.Email);
                cmd.Parameters.AddWithValue("@veiculo", cliente.Veiculo);
                cmd.Parameters.AddWithValue("@placa", cliente.Placa);
                cmd.ExecuteNonQuery();
            }
        }
        public List<Cliente> ListarClientes()
        {
            List<Cliente> cliente = new List<Cliente>();

            using(MySqlConnection conn = conexao.ObterConexao())
            {
                conn.Open();

                string sql = @"SELECT * FROM clientes";

                MySqlCommand cmd = new MySqlCommand(sql,conn);

                MySqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Cliente cliente1 = new Cliente();

                    cliente1.Id = Convert.ToInt32(reader["id"]);
                    cliente1.Nome = reader["nome"].ToString();
                    cliente1.Cpf = reader["cpf"].ToString();
                    cliente1.Telefone = reader["telefone"].ToString();
                    cliente1.Email = reader["email"].ToString();
                    cliente1.Veiculo = reader["veiculo"].ToString();
                    cliente1.Placa= reader["placa"].ToString();

                    cliente.Add(cliente1);
                }
            }
            return cliente;
        }

        public List<Cliente> PesquisarCliente(string pesquisa)
        {
            List<Cliente> cliente = new List<Cliente>();

            using(MySqlConnection conn = conexao.ObterConexao())
            {
                conn.Open();

                string sql = @"SELECT * FROM clientes 
                              WHERE id like @pesquisa
                              OR nome like @pesquisa
                              OR cpf like @pesquisa";

                MySqlCommand cmd = new MySqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@pesquisa", "%" + pesquisa + "%");
                MySqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Cliente cliente1 = new Cliente
                    {
                        Id = Convert.ToInt32(reader["id"]),
                        Nome = reader["nome"].ToString(),
                        Cpf = reader["cpf"].ToString(),
                        Telefone = reader["telefone"].ToString(),
                        Email = reader["email"].ToString(),
                        Veiculo = reader["veiculo"].ToString(),
                        Placa= reader["placa"].ToString(),
                    };
                    cliente.Add(cliente1);
                }
            }
            return cliente;
        }

        public Cliente BuscarClienteID(int id)
        { 
            Cliente cliente = null;

            using (MySqlConnection conn = conexao.ObterConexao())
            {
                conn.Open();

                string sql = @"SELECT * FROM clientes 
                        WHERE id = @id";

                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@id", id);

                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        cliente = new Cliente
                        {
                            Id = Convert.ToInt32(reader["id"]),
                            Nome = reader["nome"].ToString(),
                            Cpf = reader["cpf"].ToString(),
                            Telefone = reader["telefone"].ToString(),
                            Email = reader["email"].ToString(),
                            Veiculo = reader["veiculo"].ToString(),
                            Placa = reader["placa"].ToString(),
                        };
                    }
                }
            }
            return cliente;
        }
        public void EditarCliente(Cliente cliente)
        {
            using (MySqlConnection conn = conexao.ObterConexao())
            {
                conn.Open();

                string sql = @"UPDATE clientes 
                        SET nome = @nome,
                            cpf = @cpf,
                            email = @email,
                            veiculo = @veiculo,
                            telefone = @telefone,
                            placa = @placa
                        WHERE id = @id";

                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@nome", cliente.Nome);
                cmd.Parameters.AddWithValue("@cpf", cliente.Cpf);
                cmd.Parameters.AddWithValue("@email", cliente.Email);
                cmd.Parameters.AddWithValue("@veiculo", cliente.Veiculo);
                cmd.Parameters.AddWithValue("@telefone", cliente.Telefone);
                cmd.Parameters.AddWithValue("@placa", cliente.Placa);
                cmd.Parameters.AddWithValue("@id", cliente.Id);

                cmd.ExecuteNonQuery();
            }
        }
        public void ExcluirCLiente(int id)
        {
            using(MySqlConnection conn = conexao.ObterConexao())
            {
                conn.Open();
                string sql = "DELETE FROM clientes where id = @id";

                MySqlCommand cmd = new MySqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@id", id);

                cmd.ExecuteNonQuery();
            }
        }
    }
}