﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySqlConnector;

namespace ControleEstoqueWindowsForm
{
    class Conexao
    {
        private string conexao = "Server=localhost;user=root;database=controleestoque;port=3306;password=;";
        public MySqlConnection ObterConexao()
        {
            return new MySqlConnection(conexao);
        }
    }
}
